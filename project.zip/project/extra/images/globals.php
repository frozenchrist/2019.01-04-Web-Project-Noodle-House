<?php 

//contains arrays that store the filename of dishes.


$noodles = array(
  'beef-noodles.png',
  'veggie-noodles.png',
  'fish-noodles.png',
  'chicken-noodles.png',
  'shrimp-noodles.png',
  'spicyseafood-noodles.png',
  'meatball-noodles.png',
  'pork-noodles.png',
  'mushroom-noodles.png',
);

$rice = array(
  'beef-rice.png',
  'veggie-rice.png',
  'fish-rice.png',
  'chicken-rice.png',
  'shrimp-rice.png',
  'spicyseafood-rice.png',
  'meatball-rice.png',
  'pork-rice.png',
  'mushroom-rice.png',
  
);

?>