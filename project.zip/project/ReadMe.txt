http://xie12f.myweb.cs.uwindsor.ca/
Hi, professor,
I put all the files in the directory based on the rubric, 
but my myweb server won't process php code for some reason, same thing happened
with assignment 4. Since then, I was using XAMPP all alone. this project was all tested 
using XAMPP.
Thank you.